"""
Mentos Data Layer — point-in-time provider with leakage firewall.
Supports: FinnhubProvider (live), StooqProvider (free backfill), SyntheticProvider (testing).
No future data ever leaks through — enforced by construction.
"""

from __future__ import annotations
import os
import datetime as dt
import pandas as pd
import numpy as np
import requests
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Bar:
    """A single OHLCV bar with point-in-time metadata."""
    symbol: str
    timestamp: dt.datetime          # bar close time (UTC)
    open: float
    high: float
    low: float
    close: float
    volume: float
    source: str = "unknown"
    quality: int = 100              # 0–100 data quality score


@dataclass
class DataPoint:
    """Generic timestamped data point (non-price signals)."""
    source: str
    category: str                   # e.g. 'congressional_trade', 'sentiment'
    symbol: Optional[str]
    timestamp: dt.datetime          # when the event occurred
    available_at: dt.datetime       # when it became publicly available
    value: float                    # normalised signal value -1..1
    raw: dict = field(default_factory=dict)
    quality: int = 80


class LeakageFirewall:
    """
    Enforces point-in-time integrity.
    Every data request must declare an as_of datetime;
    any bar/event with timestamp > as_of is rejected.
    """

    @staticmethod
    def filter_bars(bars: list[Bar], as_of: dt.datetime) -> list[Bar]:
        clean = [b for b in bars if b.timestamp <= as_of]
        leaked = len(bars) - len(clean)
        if leaked:
            raise RuntimeError(
                f"LEAKAGE DETECTED: {leaked} future bars blocked (as_of={as_of})"
            )
        return clean

    @staticmethod
    def filter_points(points: list[DataPoint], as_of: dt.datetime) -> list[DataPoint]:
        return [p for p in points if p.available_at <= as_of]


class FinnhubProvider:
    """
    Fetches real OHLCV data from Finnhub free tier.
    Requires env var FINNHUB_API_KEY.
    60 calls/min on free tier; supports US equities + congressional trades.
    """

    BASE = "https://finnhub.io/api/v1"

    def __init__(self):
        self.key = os.environ.get("FINNHUB_API_KEY", "")
        if not self.key:
            raise EnvironmentError(
                "FINNHUB_API_KEY not set. "
                "Get a free key at finnhub.io/register and set it as an env variable."
            )
        self.quality = 90

    def get_bars(
        self,
        symbol: str,
        start: dt.datetime,
        end: dt.datetime,
        resolution: str = "D",
    ) -> list[Bar]:
        """Fetch daily (or intraday) OHLCV bars."""
        url = f"{self.BASE}/stock/candle"
        params = {
            "symbol": symbol,
            "resolution": resolution,
            "from": int(start.timestamp()),
            "to": int(end.timestamp()),
            "token": self.key,
        }
        resp = requests.get(url, params=params, timeout=10)
        resp.raise_for_status()
        data = resp.json()

        if data.get("s") == "no_data":
            return []

        if data.get("s") != "ok":
            raise ValueError(f"Finnhub error for {symbol}: {data}")

        bars = []
        for i, ts in enumerate(data["t"]):
            bars.append(Bar(
                symbol=symbol,
                timestamp=dt.datetime.utcfromtimestamp(ts),
                open=data["o"][i],
                high=data["h"][i],
                low=data["l"][i],
                close=data["c"][i],
                volume=data["v"][i],
                source="finnhub",
                quality=self.quality,
            ))
        return bars

    def get_congressional_trades(self, symbol: str = "") -> list[DataPoint]:
        """Fetch congressional trading disclosures (Finnhub built-in endpoint)."""
        url = f"{self.BASE}/stock/congressional-trading"
        params = {"symbol": symbol, "token": self.key}
        resp = requests.get(url, params=params, timeout=10)
        resp.raise_for_status()
        data = resp.json().get("data", [])

        points = []
        for item in data:
            try:
                tx_date = dt.datetime.strptime(item["transactionDate"], "%Y-%m-%d")
                disc_date = dt.datetime.strptime(item["filingDate"], "%Y-%m-%d")
                tx_type = item.get("transactionType", "").lower()
                value = 0.6 if "purchase" in tx_type else -0.6 if "sale" in tx_type else 0.0
                points.append(DataPoint(
                    source="finnhub_congress",
                    category="congressional_trade",
                    symbol=item.get("ticker"),
                    timestamp=tx_date,
                    available_at=disc_date,
                    value=value,
                    raw=item,
                    quality=85,
                ))
            except Exception:
                continue
        return points


class StooqProvider:
    """
    Free daily OHLCV backfill from Stooq (no API key needed).
    Used for historical backtesting when Finnhub free-tier history is limited.
    """

    BASE = "https://stooq.com/q/d/l/"

    def get_bars(
        self,
        symbol: str,
        start: dt.datetime,
        end: dt.datetime,
    ) -> list[Bar]:
        params = {
            "s": symbol.lower(),
            "d1": start.strftime("%Y%m%d"),
            "d2": end.strftime("%Y%m%d"),
            "i": "d",
        }
        resp = requests.get(self.BASE, params=params, timeout=15)
        resp.raise_for_status()

        lines = resp.text.strip().split("\n")
        if len(lines) < 2:
            return []

        bars = []
        for line in lines[1:]:
            parts = line.strip().split(",")
            if len(parts) < 6:
                continue
            try:
                bars.append(Bar(
                    symbol=symbol,
                    timestamp=dt.datetime.strptime(parts[0], "%Y-%m-%d"),
                    open=float(parts[1]),
                    high=float(parts[2]),
                    low=float(parts[3]),
                    close=float(parts[4]),
                    volume=float(parts[5]),
                    source="stooq",
                    quality=80,
                ))
            except (ValueError, IndexError):
                continue
        return sorted(bars, key=lambda b: b.timestamp)


class SyntheticProvider:
    """
    Deterministic random-walk data for unit testing.
    Clearly labelled quality=40 so it can never be confused with real data.
    """

    def __init__(self, symbols: list[str] = None, seed: int = 42):
        self.symbols = symbols or ["AAPL", "MSFT", "GOOGL", "AMZN", "TSLA"]
        self.seed = seed
        self.quality = 40

    def get_bars(
        self,
        symbol: str,
        start: dt.datetime,
        end: dt.datetime,
    ) -> list[Bar]:
        rng = np.random.default_rng(self.seed + hash(symbol) % 10000)
        days = pd.date_range(start, end, freq="B")
        price = 100.0
        bars = []
        for day in days:
            ret = rng.normal(0.0005, 0.018)
            open_ = price
            close = price * (1 + ret)
            high = max(open_, close) * (1 + abs(rng.normal(0, 0.005)))
            low = min(open_, close) * (1 - abs(rng.normal(0, 0.005)))
            vol = rng.integers(500_000, 5_000_000)
            bars.append(Bar(
                symbol=symbol,
                timestamp=day.to_pydatetime(),
                open=round(open_, 4),
                high=round(high, 4),
                low=round(low, 4),
                close=round(close, 4),
                volume=float(vol),
                source="synthetic",
                quality=self.quality,
            ))
            price = close
        return bars


class DataFrameBuilder:
    """
    Converts a list of Bars into a pandas DataFrame with point-in-time guarantee.
    The firewall is applied here — no future bars can enter.
    """

    def __init__(self, provider, as_of: dt.datetime = None):
        self.provider = provider
        self.as_of = as_of or dt.datetime.utcnow()
        self.firewall = LeakageFirewall()

    def build(
        self,
        symbol: str,
        lookback_days: int = 365,
    ) -> pd.DataFrame:
        start = self.as_of - dt.timedelta(days=lookback_days)
        raw_bars = self.provider.get_bars(symbol, start, self.as_of)
        clean_bars = self.firewall.filter_bars(raw_bars, self.as_of)

        if not clean_bars:
            return pd.DataFrame()

        df = pd.DataFrame([{
            "timestamp": b.timestamp,
            "open": b.open,
            "high": b.high,
            "low": b.low,
            "close": b.close,
            "volume": b.volume,
            "source": b.source,
            "quality": b.quality,
        } for b in clean_bars])
        df.set_index("timestamp", inplace=True)
        df.sort_index(inplace=True)
        return df
