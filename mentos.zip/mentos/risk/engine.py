"""
Mentos Risk Engine
Pre-trade gates that prevent catastrophic portfolio damage.
Every trade passes through here before execution.
"""

from __future__ import annotations
import numpy as np
import pandas as pd
from dataclasses import dataclass, field
from typing import Optional


# ── Configuration ──────────────────────────────────────────────────────────────

@dataclass
class RiskConfig:
    max_position_pct: float = 0.10      # no single position > 10% of portfolio
    max_sector_pct: float = 0.30        # no sector > 30%
    max_drawdown_kill: float = 0.15     # halt trading if drawdown exceeds 15%
    max_portfolio_var_95: float = 0.03  # daily 95% VaR limit (3%)
    min_quality_score: int = 60         # reject signals from low-quality data
    max_correlation: float = 0.80       # reject if new position correlates > 0.8 with existing


# ── Risk Assessment Output ─────────────────────────────────────────────────────

@dataclass
class RiskAssessment:
    approved: bool
    reason: str
    position_size_pct: float       # recommended position size as % of portfolio
    max_loss_pct: float            # estimated max loss on this position
    portfolio_var_95: float        # portfolio 95% VaR after adding position
    sector_exposure: float         # sector concentration after trade
    correlation_risk: float        # max correlation with existing positions
    explainability: int            # 0–100
    warnings: list[str] = field(default_factory=list)


# ── Position Sizer ─────────────────────────────────────────────────────────────

class KellySizer:
    """
    Fractional Kelly position sizing.
    Uses half-Kelly for safety (standard in professional PM).
    """

    def size(self, win_rate: float, avg_win: float, avg_loss: float, kelly_fraction: float = 0.5) -> float:
        if avg_loss == 0:
            return 0.0
        b = avg_win / avg_loss
        p = win_rate
        q = 1 - p
        kelly = (b * p - q) / b
        return max(0.0, min(kelly * kelly_fraction, 0.20))   # hard cap at 20%


# ── Performance Metrics ────────────────────────────────────────────────────────

class PerformanceMetrics:
    """
    Calculates Sharpe, Sortino, Max Drawdown, VaR, Alpha, Beta.
    All metrics match the spec requirements.
    """

    @staticmethod
    def sharpe(returns: pd.Series, risk_free: float = 0.04) -> float:
        excess = returns - risk_free / 252
        if excess.std() == 0:
            return 0.0
        return float((excess.mean() / excess.std()) * np.sqrt(252))

    @staticmethod
    def sortino(returns: pd.Series, risk_free: float = 0.04, target: float = 0.0) -> float:
        excess = returns - risk_free / 252
        downside = returns[returns < target]
        if len(downside) == 0 or downside.std() == 0:
            return 0.0
        return float((excess.mean() / downside.std()) * np.sqrt(252))

    @staticmethod
    def max_drawdown(equity_curve: pd.Series) -> float:
        roll_max = equity_curve.cummax()
        drawdown = (equity_curve - roll_max) / roll_max
        return float(drawdown.min())

    @staticmethod
    def var_95(returns: pd.Series) -> float:
        if len(returns) < 10:
            return 0.0
        return float(np.percentile(returns, 5))

    @staticmethod
    def cvar_95(returns: pd.Series) -> float:
        var = PerformanceMetrics.var_95(returns)
        tail = returns[returns <= var]
        return float(tail.mean()) if len(tail) > 0 else 0.0

    @staticmethod
    def alpha_beta(portfolio_returns: pd.Series, market_returns: pd.Series) -> tuple[float, float]:
        aligned = pd.concat([portfolio_returns, market_returns], axis=1).dropna()
        if len(aligned) < 20:
            return 0.0, 1.0
        aligned.columns = ["port", "mkt"]
        cov = np.cov(aligned["port"], aligned["mkt"])
        beta = cov[0, 1] / cov[1, 1] if cov[1, 1] != 0 else 1.0
        alpha = aligned["port"].mean() * 252 - beta * aligned["mkt"].mean() * 252
        return round(float(alpha), 4), round(float(beta), 4)

    @staticmethod
    def win_rate(returns: pd.Series) -> float:
        if len(returns) == 0:
            return 0.0
        return float((returns > 0).mean())

    @staticmethod
    def profit_factor(returns: pd.Series) -> float:
        gains = returns[returns > 0].sum()
        losses = abs(returns[returns < 0].sum())
        return float(gains / losses) if losses > 0 else float("inf")

    @staticmethod
    def full_report(returns: pd.Series, equity: pd.Series, market_returns: pd.Series = None) -> dict:
        alpha, beta = (0.0, 1.0)
        if market_returns is not None:
            alpha, beta = PerformanceMetrics.alpha_beta(returns, market_returns)
        return {
            "total_return": float((equity.iloc[-1] / equity.iloc[0]) - 1) if len(equity) > 1 else 0.0,
            "sharpe": PerformanceMetrics.sharpe(returns),
            "sortino": PerformanceMetrics.sortino(returns),
            "max_drawdown": PerformanceMetrics.max_drawdown(equity),
            "var_95": PerformanceMetrics.var_95(returns),
            "cvar_95": PerformanceMetrics.cvar_95(returns),
            "win_rate": PerformanceMetrics.win_rate(returns),
            "profit_factor": PerformanceMetrics.profit_factor(returns),
            "alpha": alpha,
            "beta": beta,
            "n_trades": len(returns),
            "avg_return": float(returns.mean()),
            "volatility": float(returns.std() * np.sqrt(252)),
        }


# ── Risk Engine ────────────────────────────────────────────────────────────────

class RiskEngine:
    """
    Pre-trade risk gatekeeper.
    Called before every order — returns RiskAssessment with approved=True/False.
    """

    def __init__(self, config: RiskConfig = None):
        self.config = config or RiskConfig()
        self.sizer = KellySizer()
        self.peak_equity: float = 1.0
        self.current_equity: float = 1.0
        self.kill_switch_active: bool = False

    def update_equity(self, equity: float):
        if equity > self.peak_equity:
            self.peak_equity = equity
        self.current_equity = equity
        drawdown = (self.peak_equity - equity) / self.peak_equity
        if drawdown >= self.config.max_drawdown_kill:
            self.kill_switch_active = True

    def assess(
        self,
        symbol: str,
        signal_value: float,
        signal_quality: int,
        portfolio_value: float,
        current_positions: dict,        # {symbol: position_value}
        sector_map: dict,               # {symbol: sector}
        returns_history: pd.Series,
        win_rate: float = 0.5,
        avg_win: float = 0.02,
        avg_loss: float = 0.01,
    ) -> RiskAssessment:

        warnings = []

        # Kill switch check
        if self.kill_switch_active:
            return RiskAssessment(
                approved=False,
                reason=f"KILL SWITCH ACTIVE: drawdown exceeded {self.config.max_drawdown_kill:.0%}",
                position_size_pct=0.0,
                max_loss_pct=0.0,
                portfolio_var_95=0.0,
                sector_exposure=0.0,
                correlation_risk=0.0,
                explainability=100,
                warnings=["All trading halted until manual review."],
            )

        # Data quality check
        if signal_quality < self.config.min_quality_score:
            return RiskAssessment(
                approved=False,
                reason=f"Data quality {signal_quality} below minimum {self.config.min_quality_score}",
                position_size_pct=0.0,
                max_loss_pct=0.0,
                portfolio_var_95=0.0,
                sector_exposure=0.0,
                correlation_risk=0.0,
                explainability=90,
            )

        # Position size
        raw_size = self.sizer.size(win_rate, avg_win, avg_loss)
        position_size_pct = min(raw_size, self.config.max_position_pct)
        position_value = portfolio_value * position_size_pct

        # Sector concentration
        target_sector = sector_map.get(symbol, "Unknown")
        sector_value = sum(
            v for s, v in current_positions.items()
            if sector_map.get(s) == target_sector
        )
        sector_exposure = (sector_value + position_value) / portfolio_value

        if sector_exposure > self.config.max_sector_pct:
            warnings.append(f"Sector {target_sector} would reach {sector_exposure:.0%} (limit {self.config.max_sector_pct:.0%})")
            position_size_pct *= (self.config.max_sector_pct / sector_exposure)

        # VaR estimate
        var_95 = PerformanceMetrics.var_95(returns_history) if len(returns_history) > 10 else -0.02
        portfolio_var = abs(var_95) * (1 + position_size_pct)

        if portfolio_var > self.config.max_portfolio_var_95:
            warnings.append(f"Estimated VaR {portfolio_var:.2%} exceeds limit {self.config.max_portfolio_var_95:.2%}")
            position_size_pct = max(position_size_pct * 0.5, 0.01)

        # Concentration check
        existing_pct = current_positions.get(symbol, 0) / portfolio_value if portfolio_value > 0 else 0
        if existing_pct + position_size_pct > self.config.max_position_pct:
            position_size_pct = max(0, self.config.max_position_pct - existing_pct)
            warnings.append(f"Position capped at {self.config.max_position_pct:.0%} limit")

        if position_size_pct < 0.005:
            return RiskAssessment(
                approved=False,
                reason="Position size too small after risk adjustments (<0.5%)",
                position_size_pct=0.0,
                max_loss_pct=avg_loss,
                portfolio_var_95=portfolio_var,
                sector_exposure=sector_exposure,
                correlation_risk=0.0,
                explainability=95,
                warnings=warnings,
            )

        return RiskAssessment(
            approved=True,
            reason="All risk checks passed",
            position_size_pct=round(position_size_pct, 4),
            max_loss_pct=round(avg_loss, 4),
            portfolio_var_95=round(portfolio_var, 4),
            sector_exposure=round(sector_exposure, 4),
            correlation_risk=0.0,
            explainability=92,
            warnings=warnings,
        )
