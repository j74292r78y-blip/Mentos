"""
Mentos Risk Engine
==================
Per spec: "You must always evaluate risk before return." This module
computes risk metrics BEFORE a trade is allowed to execute, and can
veto/resize trades. Hard position/sector limits are enforced here,
not left to the optimizer to discover - per addendum #2 in the brief
("Mentos might decide to put 90% of the portfolio into one stock").
"""

from __future__ import annotations
import math
import datetime as dt
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class RiskLimits:
    """Hard constraints - never violated regardless of model conviction."""
    max_position_pct: float = 0.10        # no single position > 10% of portfolio
    max_sector_pct: float = 0.30          # no sector > 30% of portfolio
    max_portfolio_volatility_annualized: float = 0.25
    max_correlation_cluster_pct: float = 0.40  # positions correlated >0.7 to each other
    max_drawdown_kill_switch: float = 0.20     # halt new risk-taking past this DD


@dataclass
class Position:
    symbol: str
    sector: str
    shares: float
    entry_price: float
    current_price: float

    @property
    def market_value(self) -> float:
        return self.shares * self.current_price

    @property
    def unrealized_pnl_pct(self) -> float:
        if self.entry_price == 0:
            return 0.0
        return (self.current_price - self.entry_price) / self.entry_price


@dataclass
class RiskAssessment:
    approved: bool
    position_size_pct: float
    max_loss_estimate: float
    sector_exposure_after: float
    concentration_flag: bool
    correlation_flag: bool
    volatility_exposure: float
    reasons: list[str] = field(default_factory=list)


class RiskEngine:
    def __init__(self, limits: Optional[RiskLimits] = None):
        self.limits = limits or RiskLimits()

    # -- core portfolio-level metrics -------------------------------------

    @staticmethod
    def max_drawdown(equity_curve: list[float]) -> float:
        if not equity_curve:
            return 0.0
        peak = equity_curve[0]
        max_dd = 0.0
        for v in equity_curve:
            peak = max(peak, v)
            if peak > 0:
                dd = (peak - v) / peak
                max_dd = max(max_dd, dd)
        return max_dd

    @staticmethod
    def annualized_volatility(returns: list[float]) -> float:
        if len(returns) < 2:
            return 0.0
        mean = sum(returns) / len(returns)
        var = sum((r - mean) ** 2 for r in returns) / (len(returns) - 1)
        return math.sqrt(var) * math.sqrt(252)

    @staticmethod
    def sharpe_ratio(returns: list[float], risk_free_rate: float = 0.0) -> Optional[float]:
        if len(returns) < 2:
            return None
        mean = sum(returns) / len(returns)
        excess = mean - risk_free_rate / 252
        vol = RiskEngine.annualized_volatility(returns) / math.sqrt(252)
        if vol == 0:
            return None
        return (excess / vol) * math.sqrt(252)

    @staticmethod
    def sortino_ratio(returns: list[float], risk_free_rate: float = 0.0) -> Optional[float]:
        if len(returns) < 2:
            return None
        mean = sum(returns) / len(returns)
        excess = mean - risk_free_rate / 252
        downside = [r for r in returns if r < 0]
        if not downside:
            return None  # no downside observations -> not computable, don't fabricate
        downside_dev = math.sqrt(sum(r ** 2 for r in downside) / len(downside))
        if downside_dev == 0:
            return None
        return (excess / downside_dev) * math.sqrt(252)

    @staticmethod
    def correlation(returns_a: list[float], returns_b: list[float]) -> Optional[float]:
        n = min(len(returns_a), len(returns_b))
        if n < 10:
            return None
        a, b = returns_a[-n:], returns_b[-n:]
        mean_a, mean_b = sum(a) / n, sum(b) / n
        cov = sum((a[i] - mean_a) * (b[i] - mean_b) for i in range(n))
        var_a = sum((x - mean_a) ** 2 for x in a)
        var_b = sum((x - mean_b) ** 2 for x in b)
        if var_a == 0 or var_b == 0:
            return None
        return cov / math.sqrt(var_a * var_b)

    @staticmethod
    def value_at_risk(returns: list[float], confidence: float = 0.95) -> Optional[float]:
        """Historical VaR - tail risk sensitivity, simplest defensible form."""
        if len(returns) < 20:
            return None
        sorted_r = sorted(returns)
        idx = int((1 - confidence) * len(sorted_r))
        return sorted_r[idx]

    # -- pre-trade gate -----------------------------------------------------

    def assess_trade(self, proposed_symbol: str, proposed_sector: str,
                      proposed_value: float, portfolio_value: float,
                      existing_positions: list[Position],
                      proposed_return_series: Optional[list[float]] = None,
                      sector_return_series: Optional[dict[str, list[float]]] = None,
                      current_drawdown: float = 0.0) -> RiskAssessment:
        reasons = []
        approved = True

        if portfolio_value <= 0:
            return RiskAssessment(False, 0, 0, 0, False, False, 0,
                                   reasons=["invalid_portfolio_value"])

        position_pct = proposed_value / portfolio_value
        if position_pct > self.limits.max_position_pct:
            approved = False
            reasons.append(
                f"position_size {position_pct:.1%} exceeds max_position_pct {self.limits.max_position_pct:.1%}"
            )

        sector_value = sum(p.market_value for p in existing_positions if p.sector == proposed_sector)
        sector_exposure_after = (sector_value + proposed_value) / portfolio_value
        if sector_exposure_after > self.limits.max_sector_pct:
            approved = False
            reasons.append(
                f"sector_exposure_after {sector_exposure_after:.1%} exceeds max_sector_pct {self.limits.max_sector_pct:.1%}"
            )

        concentration_flag = position_pct > self.limits.max_position_pct * 0.8
        if concentration_flag and approved:
            reasons.append("approaching position concentration limit (>80% of max)")

        correlation_flag = False
        if proposed_return_series and sector_return_series:
            high_corr_value = 0.0
            for p in existing_positions:
                other_series = sector_return_series.get(p.symbol)
                if other_series:
                    corr = self.correlation(proposed_return_series, other_series)
                    if corr is not None and corr > 0.7:
                        high_corr_value += p.market_value
            cluster_pct = (high_corr_value + proposed_value) / portfolio_value
            if cluster_pct > self.limits.max_correlation_cluster_pct:
                correlation_flag = True
                approved = False
                reasons.append(
                    f"correlation_cluster_exposure {cluster_pct:.1%} exceeds max_correlation_cluster_pct {self.limits.max_correlation_cluster_pct:.1%}"
                )

        if current_drawdown >= self.limits.max_drawdown_kill_switch:
            approved = False
            reasons.append(
                f"portfolio drawdown {current_drawdown:.1%} >= kill_switch {self.limits.max_drawdown_kill_switch:.1%} - new risk-taking halted"
            )

        volatility_exposure = self.annualized_volatility(proposed_return_series) if proposed_return_series else 0.0
        if volatility_exposure > self.limits.max_portfolio_volatility_annualized:
            reasons.append(
                f"instrument annualized_volatility {volatility_exposure:.1%} is high relative to portfolio target {self.limits.max_portfolio_volatility_annualized:.1%} (informational, not auto-vetoed)"
            )

        # max loss estimate: simple stop-distance based, conservative
        max_loss_estimate = proposed_value * 0.10  # assumes worst-case 10% gap risk if no stop fills

        if approved and not reasons:
            reasons.append("within all configured risk limits")

        return RiskAssessment(
            approved=approved,
            position_size_pct=position_pct,
            max_loss_estimate=max_loss_estimate,
            sector_exposure_after=sector_exposure_after,
            concentration_flag=concentration_flag,
            correlation_flag=correlation_flag,
            volatility_exposure=volatility_exposure,
            reasons=reasons,
        )
