# Mentos — Core Engine v0.01

## What's real vs. what's not

- **Code/logic**: real, runnable, tested end-to-end (see test commands below).
- **Data in this session**: SYNTHETIC (quality score 40/100) because this sandbox has
  no network egress. Stooq's free EOD CSV endpoint returned 403 (proxy-blocked, not a
  code bug) — `data/provider.py` includes `StooqProvider`, which will work the moment
  you run this on your own machine with internet access.
- **For real data right now without code changes**: use `ManualCSVProvider` in
  `data/provider.py` — export price history from your broker/Yahoo Finance/Stooq's
  website as CSV (Date,Open,High,Low,Close,Volume) and point it at the file.

## What's built (4 layers)

1. **`data/provider.py`** — point-in-time data layer. Every price record carries
   `available_time` separate from `event_time`; queries only ever return what was
   knowable as of a given timestamp. This is the structural fix for look-ahead bias —
   it's not a rule Claude/the model has to remember to follow, it's enforced by the
   only query method that exists (`as_of`).

2. **`signals/engine.py`** — every signal is a `SignalHypothesis` with mandatory
   fields (hypothesis, inputs, logic, failure conditions, metrics) before it can run.
   Includes `MomentumSignal` and `MeanReversionSignal` as worked examples (intentionally
   simple, NOT presented as "good" — they're untested), `RegimeDetector`,
   `CalibrationTracker` (checks if stated confidence matches empirical hit rate), and
   `decay_profile()` which computes Information Coefficient across the 6 required
   horizons (1d/3d/1w/1m/3m/6m).

3. **`risk/engine.py`** — hard pre-trade gates (position size, sector concentration,
   correlation clustering, drawdown kill-switch) plus Sharpe/Sortino/VaR/max-drawdown.
   A trade that breaches a limit is rejected with a stated reason, not silently resized.

4. **`backtest/engine.py`** — walks forward day-by-day, calling only `as_of()`, applying
   realistic execution costs (slippage + spread + commission) to every fill, logging
   full evidence per trade, and producing `walk_forward_split()` windows for proper
   out-of-sample testing.

## Run it yourself

```bash
pip install --break-system-packages  # no external deps needed actually, stdlib only
python3 -c "
from data.provider import SyntheticProvider, build_frame
from signals.engine import MomentumSignal, MeanReversionSignal
from risk.engine import RiskEngine, RiskLimits
from backtest.engine import BacktestEngine
import datetime as dt

frame = build_frame(SyntheticProvider(seed=1), 'synthetic', ['AAPL','MSFT','SPY'], dt.date(2023,1,1), dt.date(2024,1,1))
engine = BacktestEngine(frame, [MomentumSignal(20), MeanReversionSignal(10)], RiskEngine(RiskLimits()))
result = engine.run(['AAPL','MSFT'], dt.date(2023,2,1), dt.date(2023,12,1))
print(result.total_return_pct(), 'pct return,', len(result.trades), 'trades')
"
```

## Honest assessment / what I'd push back on in the original spec

- "Profitability is the primary objective... accuracy/risk secondary" (in the uploaded
  doc) directly contradicts "risk-adjusted returns" and "never optimize for best
  backtest" (in your pasted instructions). I built to the risk-first version — flag if
  you actually want profit-primary, but that's the version most likely to overfit.
- Congressional trading disclosures, social sentiment, etc. are listed as data sources
  to track. Several have genuinely weak/contested academic support as alpha sources
  (lagged disclosure windows, publication-already-priced-in effects). I haven't built
  those collectors yet — wanted the core engine validated first. Tell me if you want
  me to prioritize one over polish elsewhere.
- A real platform of this scope (live data ingestion, persistent DB, scheduler, auth,
  many data sources) is a multi-week engineering project, not something that fits in
  artifacts/sandbox code. What I can keep doing here: extend this same codebase one
  module at a time, each one runnable and tested like the four above.

## Next steps (pick what you want next)

- Wire in a real free data source you can access (Yahoo Finance via `yfinance` if you
  run locally, or upload a CSV here)
- Add more signals + run real decay/IC analysis against real prices
- Build the Capital Allocation / position-sizing optimizer
- Add the Signal Leaderboard + Hall of Fame versioning system
- Stress-test against real historical crises (2008, 2020, 2022) once real data is wired in
