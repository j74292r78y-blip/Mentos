# Mentos — Paper Trading Intelligence Platform

**Version 1.0** | Paper Trading Only | No Real Money

---

## What This Is

Mentos is a research and simulation platform for stock market analysis.
It uses real market data to run backtests and paper trades — no real money is ever used.

---

## Files in This Repo

```
mentos/
├── data/
│   └── provider.py          # Data layer: Finnhub, Stooq, Synthetic
├── signals/
│   └── engine.py            # Signal engine: momentum, RSI, volatility, volume
├── risk/
│   └── engine.py            # Risk engine: position sizing, VaR, kill switch
├── backtest/
│   └── engine.py            # Backtest: walk-forward, realistic execution
├── trading/
│   └── alpaca_connector.py  # Alpaca paper trading connector
├── step1_test_connection.py # First test: verifies Alpaca connection
└── requirements.txt
```

---

## Render Setup (Cloud Hosting)

**Build Command:**
```
unzip mentos.zip && pip install -r mentos/requirements.txt
```

**Start Command:**
```
python mentos/step1_test_connection.py
```

**Environment Variables to add in Render:**

| Name | Value |
|------|-------|
| `ALPACA_API_KEY_ID` | Your Alpaca Paper Trading API Key |
| `ALPACA_SECRET_KEY` | Your Alpaca Paper Trading Secret Key |

**Never put API keys in code or GitHub. Render stores them securely.**

---

## Getting Your Alpaca Keys

1. Go to **alpaca.markets**
2. Sign up free — no card required
3. Select **Paper Trading** (not Live)
4. Find **API Keys** on the dashboard
5. Copy both the Key ID and Secret Key
6. Add them as Environment Variables in Render

---

## Safety

- Paper trading only by default
- Live trading requires two separate explicit code confirmations
- Kill switch activates automatically if drawdown exceeds 15%
- No API keys ever stored in code

---

## Version History

| Version | What Changed | Date |
|---------|-------------|------|
| 1.0 | Initial build: data, signals, risk, backtest, Alpaca connector | 2026 |
