"""
Mentos Backtest Engine
Walk-forward validation, realistic execution costs, time-travel mode.
No future data ever used — enforced by the DataFrameBuilder firewall.
"""

from __future__ import annotations
import datetime as dt
import numpy as np
import pandas as pd
from dataclasses import dataclass, field
from typing import Optional

from mentos.signals.engine import SignalRegistry, SignalResult
from mentos.risk.engine import RiskEngine, RiskConfig, PerformanceMetrics


# ── Trade Record ───────────────────────────────────────────────────────────────

@dataclass
class Trade:
    trade_id: str
    symbol: str
    entry_date: dt.datetime
    exit_date: Optional[dt.datetime]
    entry_price: float
    exit_price: Optional[float]
    shares: float
    direction: str              # 'long' or 'short'
    signal_name: str
    signal_value: float
    regime: str
    confidence: float
    risk_approved: bool
    position_size_pct: float
    pnl: float = 0.0
    return_pct: float = 0.0
    holding_days: int = 0
    exit_reason: str = ""
    explainability: int = 80
    evidence: dict = field(default_factory=dict)


# ── Execution Engine (realistic costs) ────────────────────────────────────────

@dataclass
class ExecutionConfig:
    commission_pct: float = 0.001       # 0.1% per trade
    slippage_pct: float = 0.0005        # 0.05% slippage
    bid_ask_spread_pct: float = 0.001   # 0.1% bid-ask
    max_position_liquidity: float = 0.01  # max 1% of avg daily volume


class RealisticExecutor:

    def __init__(self, config: ExecutionConfig = None):
        self.config = config or ExecutionConfig()

    def fill_price(self, mid_price: float, side: str) -> float:
        half_spread = mid_price * self.config.bid_ask_spread_pct / 2
        slippage = mid_price * self.config.slippage_pct
        if side == "buy":
            return mid_price + half_spread + slippage
        return mid_price - half_spread - slippage

    def commission(self, trade_value: float) -> float:
        return trade_value * self.config.commission_pct

    def net_return(self, entry: float, exit_: float, direction: str) -> float:
        gross = (exit_ / entry - 1) if direction == "long" else (entry / exit_ - 1)
        cost = self.config.commission_pct * 2 + self.config.bid_ask_spread_pct + self.config.slippage_pct * 2
        return gross - cost


# ── Walk-Forward Validator ─────────────────────────────────────────────────────

@dataclass
class WalkForwardWindow:
    window_id: int
    train_start: dt.datetime
    train_end: dt.datetime
    test_start: dt.datetime
    test_end: dt.datetime
    train_sharpe: float
    test_sharpe: float
    test_return: float
    test_drawdown: float
    n_trades: int
    regime: str


class WalkForwardValidator:

    def generate_windows(
        self,
        start: dt.datetime,
        end: dt.datetime,
        train_months: int = 12,
        test_months: int = 3,
    ) -> list[tuple[dt.datetime, dt.datetime, dt.datetime, dt.datetime]]:
        """Generate (train_start, train_end, test_start, test_end) tuples."""
        windows = []
        cursor = start
        while True:
            train_end = cursor + dt.timedelta(days=30 * train_months)
            test_end = train_end + dt.timedelta(days=30 * test_months)
            if test_end > end:
                break
            windows.append((cursor, train_end, train_end, test_end))
            cursor = cursor + dt.timedelta(days=30 * test_months)
        return windows


# ── Main Backtest Engine ───────────────────────────────────────────────────────

class BacktestEngine:
    """
    Full backtest with:
    - Time-travel mode (strict point-in-time)
    - Walk-forward validation
    - Realistic execution
    - Explainable trade log
    - Regime-conditioned signals
    """

    def __init__(
        self,
        signal_registry: SignalRegistry,
        risk_engine: RiskEngine,
        execution_config: ExecutionConfig = None,
        initial_capital: float = 100_000,
    ):
        self.signals = signal_registry
        self.risk = risk_engine
        self.executor = RealisticExecutor(execution_config)
        self.initial_capital = initial_capital

    def run(
        self,
        price_data: dict[str, pd.DataFrame],   # {symbol: df with OHLCV index=timestamp}
        start: dt.datetime,
        end: dt.datetime,
        market_symbol: str = "SPY",
        holding_days: int = 21,
        top_n: int = 5,
        sector_map: dict = None,
    ) -> dict:
        """
        Full backtest. Returns dict with equity curve, trades, metrics, walk-forward windows.
        """
        sector_map = sector_map or {}
        market_df = price_data.get(market_symbol, list(price_data.values())[0])

        dates = pd.date_range(start, end, freq="B")
        equity = self.initial_capital
        equity_curve = []
        trades: list[Trade] = []
        open_trades: list[Trade] = []
        portfolio_returns = []
        trade_counter = 0

        for i, date in enumerate(dates):
            # Close trades that have reached holding period
            still_open = []
            for t in open_trades:
                held = (date - t.entry_date).days
                if held >= holding_days:
                    sym_df = price_data.get(t.symbol)
                    if sym_df is None or sym_df.empty:
                        still_open.append(t)
                        continue
                    available = sym_df[sym_df.index <= date]
                    if available.empty:
                        still_open.append(t)
                        continue
                    exit_px = self.executor.fill_price(available["close"].iloc[-1], "sell")
                    ret = self.executor.net_return(t.entry_price, exit_px, t.direction)
                    trade_value = equity * t.position_size_pct
                    pnl = trade_value * ret
                    equity += pnl
                    t.exit_date = date
                    t.exit_price = exit_px
                    t.pnl = pnl
                    t.return_pct = ret
                    t.holding_days = held
                    t.exit_reason = "holding_period"
                    trades.append(t)
                    portfolio_returns.append(ret * t.position_size_pct)
                else:
                    still_open.append(t)
            open_trades = still_open

            # Only evaluate signals on rebalance dates (weekly)
            if i % 5 != 0:
                equity_curve.append({"date": date, "equity": equity})
                continue

            # Get point-in-time data (strict: only bars up to current date)
            pit_data = {}
            for sym, df in price_data.items():
                slice_ = df[df.index <= date]
                if len(slice_) >= 63:
                    pit_data[sym] = slice_

            if not pit_data:
                equity_curve.append({"date": date, "equity": equity})
                continue

            market_slice = market_df[market_df.index <= date]
            signal_results = self.signals.compute_all(pit_data, date, market_slice)

            if not signal_results:
                equity_curve.append({"date": date, "equity": equity})
                continue

            # Rank signals — pick top N by absolute value × confidence
            scored = sorted(
                signal_results,
                key=lambda r: abs(r.value) * r.confidence,
                reverse=True,
            )[:top_n * 2]

            # Avoid adding to symbols already open
            open_symbols = {t.symbol for t in open_trades}
            current_positions = {t.symbol: equity * t.position_size_pct for t in open_trades}
            returns_hist = pd.Series(portfolio_returns[-63:] if portfolio_returns else [0.0])

            self.risk.update_equity(equity)

            added = 0
            for sr in scored:
                if sr.symbol in open_symbols:
                    continue
                if added >= top_n:
                    break
                if sr.value <= 0:
                    continue  # long-only for now

                assessment = self.risk.assess(
                    symbol=sr.symbol,
                    signal_value=sr.value,
                    signal_quality=sr.quality,
                    portfolio_value=equity,
                    current_positions=current_positions,
                    sector_map=sector_map,
                    returns_history=returns_hist,
                )
                if not assessment.approved:
                    continue

                sym_df = pit_data.get(sr.symbol)
                if sym_df is None or sym_df.empty:
                    continue

                entry_mid = sym_df["close"].iloc[-1]
                entry_px = self.executor.fill_price(entry_mid, "buy")
                trade_counter += 1

                t = Trade(
                    trade_id=f"T{trade_counter:04d}",
                    symbol=sr.symbol,
                    entry_date=date,
                    exit_date=None,
                    entry_price=entry_px,
                    exit_price=None,
                    shares=(equity * assessment.position_size_pct) / entry_px,
                    direction="long",
                    signal_name=sr.signal_name,
                    signal_value=sr.value,
                    regime=sr.regime,
                    confidence=sr.confidence,
                    risk_approved=True,
                    position_size_pct=assessment.position_size_pct,
                    explainability=assessment.explainability,
                    evidence=sr.evidence,
                )
                open_trades.append(t)
                current_positions[sr.symbol] = equity * assessment.position_size_pct
                open_symbols.add(sr.symbol)
                added += 1

            equity_curve.append({"date": date, "equity": equity})

        # Close any remaining open trades at last available price
        for t in open_trades:
            sym_df = price_data.get(t.symbol)
            if sym_df is not None and not sym_df.empty:
                exit_px = self.executor.fill_price(sym_df["close"].iloc[-1], "sell")
                ret = self.executor.net_return(t.entry_price, exit_px, t.direction)
                pnl = equity * t.position_size_pct * ret
                equity += pnl
                t.exit_date = end
                t.exit_price = exit_px
                t.pnl = pnl
                t.return_pct = ret
                t.exit_reason = "end_of_backtest"
                trades.append(t)

        eq_series = pd.Series(
            [e["equity"] for e in equity_curve],
            index=[e["date"] for e in equity_curve],
        )
        ret_series = pd.Series([t.return_pct for t in trades]) if trades else pd.Series([0.0])
        market_ret = market_df["close"].pct_change().dropna()

        metrics = PerformanceMetrics.full_report(ret_series, eq_series, market_ret)
        metrics["n_trades"] = len(trades)

        return {
            "equity_curve": equity_curve,
            "trades": trades,
            "metrics": metrics,
            "final_equity": equity,
            "open_trades": open_trades,
        }
