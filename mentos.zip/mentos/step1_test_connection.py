"""
Mentos Step 1: Test Connection
This is the first script Render runs.
It checks Alpaca paper trading connects successfully.
Paste nothing into here — keys come from environment variables only.
"""

import os
import sys
import datetime as dt


def test_alpaca():
    print("=" * 50)
    print("MENTOS — Step 1: Connection Test")
    print("=" * 50)

    key = os.environ.get("ALPACA_API_KEY_ID", "")
    secret = os.environ.get("ALPACA_SECRET_KEY", "")

    if not key:
        print("❌ ALPACA_API_KEY_ID not set in environment variables.")
        print("   Set it in Render → Environment → Add Variable")
        sys.exit(1)

    if not secret:
        print("❌ ALPACA_SECRET_KEY not set in environment variables.")
        print("   Set it in Render → Environment → Add Variable")
        sys.exit(1)

    print(f"✅ Credentials found (key ends in ...{key[-4:]})")

    try:
        from alpaca.trading.client import TradingClient
    except ImportError:
        print("❌ alpaca-py not installed. Check requirements.txt")
        sys.exit(1)

    try:
        client = TradingClient(
            api_key=key,
            secret_key=secret,
            paper=True,
        )
        account = client.get_account()
        equity = float(account.equity)
        buying_power = float(account.buying_power)

        print(f"✅ Connected to Alpaca Paper Trading")
        print(f"   Account Equity:   ${equity:>12,.2f}")
        print(f"   Buying Power:     ${buying_power:>12,.2f}")
        print(f"   Status:           {account.status}")
        print(f"   Timestamp:        {dt.datetime.utcnow().isoformat()}Z")

        positions = client.get_all_positions()
        print(f"   Open Positions:   {len(positions)}")

        print()
        print("✅ Step 1 PASSED — Mentos is connected and ready.")
        return True

    except Exception as e:
        print(f"❌ Connection failed: {e}")
        print()
        print("Common causes:")
        print("  • Wrong API key or secret")
        print("  • Key is for Live account, not Paper Trading")
        print("  • Alpaca account not fully set up")
        sys.exit(1)


if __name__ == "__main__":
    test_alpaca()
