"""
Mentos Signal Engine
Every signal is a testable hypothesis with IC decay analysis and regime conditioning.
Signals earn their weight through evidence — no assumptions.
"""

from __future__ import annotations
import datetime as dt
import numpy as np
import pandas as pd
from dataclasses import dataclass, field
from typing import Callable, Optional
from scipy import stats


# ── Decay horizons the spec requires ──────────────────────────────────────────
DECAY_HORIZONS = [1, 3, 5, 21, 63, 126]  # trading days: 1d,3d,1w,1m,3m,6m


@dataclass
class SignalResult:
    """Output of one signal evaluation at a point in time."""
    signal_name: str
    symbol: str
    timestamp: dt.datetime
    value: float          # normalised -1..1  (-1=strong sell, +1=strong buy)
    confidence: float     # 0..1
    quality: int          # 0..100 data quality of underlying source
    regime: str           # market regime at time of signal
    evidence: dict = field(default_factory=dict)   # human-readable breakdown


@dataclass
class ICRecord:
    """Information coefficient for one horizon."""
    horizon_days: int
    ic: float             # rank correlation of signal vs fwd return
    ic_std: float
    n_obs: int
    p_value: float


@dataclass
class SignalMetrics:
    """Full performance profile for one signal."""
    signal_name: str
    ic_by_horizon: list[ICRecord]
    win_rate: float
    sharpe: float
    sortino: float
    avg_return: float
    n_trades: int
    regime_breakdown: dict   # {regime: mean_ic}
    explainability: int      # 0–100


class BaseSignal:
    """
    Abstract base. Subclass and implement `compute`.
    Every signal must define its hypothesis upfront.
    """

    name: str = "base"
    hypothesis: str = "Undefined hypothesis"
    data_quality: int = 80

    def compute(self, df: pd.DataFrame, as_of: dt.datetime) -> Optional[float]:
        """Return normalised value -1..1 or None if data insufficient."""
        raise NotImplementedError

    def evaluate(self, df: pd.DataFrame, as_of: dt.datetime, symbol: str, regime: str) -> Optional[SignalResult]:
        val = self.compute(df, as_of)
        if val is None:
            return None
        conf = min(1.0, abs(val) * 0.9 + 0.1)
        return SignalResult(
            signal_name=self.name,
            symbol=symbol,
            timestamp=as_of,
            value=round(val, 4),
            confidence=round(conf, 4),
            quality=self.data_quality,
            regime=regime,
            evidence={"hypothesis": self.hypothesis},
        )


# ── Concrete signals ───────────────────────────────────────────────────────────

class MomentumSignal(BaseSignal):
    name = "momentum_12_1"
    hypothesis = "Stocks with strong 12-month price momentum (excluding last month) outperform over the next 1–3 months."
    data_quality = 95

    def __init__(self, lookback_days: int = 252, skip_days: int = 21):
        self.lookback = lookback_days
        self.skip = skip_days

    def compute(self, df: pd.DataFrame, as_of: dt.datetime) -> Optional[float]:
        if len(df) < self.lookback:
            return None
        recent = df["close"].iloc[-self.skip] if len(df) > self.skip else df["close"].iloc[-1]
        past = df["close"].iloc[-self.lookback]
        if past <= 0:
            return None
        raw_mom = (recent / past) - 1.0
        return float(np.tanh(raw_mom * 2))   # compress to -1..1


class MeanReversionSignal(BaseSignal):
    name = "mean_reversion_rsi"
    hypothesis = "Stocks with RSI < 30 are oversold and tend to revert upward over 1–5 days."
    data_quality = 90

    def __init__(self, period: int = 14):
        self.period = period

    def compute(self, df: pd.DataFrame, as_of: dt.datetime) -> Optional[float]:
        if len(df) < self.period + 1:
            return None
        closes = df["close"].values
        deltas = np.diff(closes[-(self.period + 1):])
        gains = np.where(deltas > 0, deltas, 0).mean()
        losses = np.where(deltas < 0, -deltas, 0).mean()
        if losses == 0:
            return -0.5
        rs = gains / losses
        rsi = 100 - (100 / (1 + rs))
        # RSI < 30 → buy signal, RSI > 70 → sell signal
        return float(np.tanh((50 - rsi) / 25))


class VolatilityRegimeSignal(BaseSignal):
    name = "volatility_regime"
    hypothesis = "Stocks with contracting volatility (realised vol decreasing) tend to break out directionally."
    data_quality = 88

    def __init__(self, short: int = 10, long: int = 30):
        self.short = short
        self.long = long

    def compute(self, df: pd.DataFrame, as_of: dt.datetime) -> Optional[float]:
        if len(df) < self.long + 1:
            return None
        returns = df["close"].pct_change().dropna()
        short_vol = returns.iloc[-self.short:].std()
        long_vol = returns.iloc[-self.long:].std()
        if long_vol == 0:
            return None
        ratio = short_vol / long_vol
        # ratio < 1 → vol contracting → moderate bullish signal
        return float(np.tanh((1 - ratio) * 3))


class VolumeBreakoutSignal(BaseSignal):
    name = "volume_breakout"
    hypothesis = "Price moves on volume > 2x average have stronger follow-through."
    data_quality = 92

    def __init__(self, vol_window: int = 20):
        self.vol_window = vol_window

    def compute(self, df: pd.DataFrame, as_of: dt.datetime) -> Optional[float]:
        if len(df) < self.vol_window + 1:
            return None
        avg_vol = df["volume"].iloc[-self.vol_window - 1:-1].mean()
        last_vol = df["volume"].iloc[-1]
        last_ret = df["close"].pct_change().iloc[-1]
        if avg_vol == 0:
            return None
        vol_ratio = last_vol / avg_vol
        direction = np.sign(last_ret)
        strength = min(vol_ratio / 3, 1.0)
        return float(direction * strength)


# ── Regime Detector ────────────────────────────────────────────────────────────

class RegimeDetector:
    """
    Classifies market conditions from a market-index DataFrame.
    Output labels match the spec: Bull, Bear, Sideways, HighVol, LowVol, RiskOn, RiskOff
    """

    def detect(self, market_df: pd.DataFrame) -> str:
        if len(market_df) < 63:
            return "Unknown"
        returns = market_df["close"].pct_change().dropna()
        roll_ret = returns.iloc[-63:].mean() * 252      # annualised
        vol = returns.iloc[-21:].std() * np.sqrt(252)

        if vol > 0.30:
            return "HighVolatility"
        elif vol < 0.12:
            return "LowVolatility"
        elif roll_ret > 0.15:
            return "Bull"
        elif roll_ret < -0.10:
            return "Bear"
        else:
            return "Sideways"


# ── Decay Analyser ─────────────────────────────────────────────────────────────

class DecayAnalyser:
    """
    Measures how quickly a signal loses predictive power across the six required horizons.
    Uses rank IC (Spearman correlation) as the primary measure.
    """

    def analyse(
        self,
        signal_series: pd.Series,
        price_df: pd.DataFrame,
        symbol: str,
    ) -> list[ICRecord]:
        records = []
        closes = price_df["close"]

        for h in DECAY_HORIZONS:
            fwd_returns = closes.shift(-h) / closes - 1
            aligned = pd.concat([signal_series, fwd_returns], axis=1).dropna()
            aligned.columns = ["signal", "fwd"]

            if len(aligned) < 20:
                continue

            corr, pval = stats.spearmanr(aligned["signal"], aligned["fwd"])
            ic_std = np.std([
                stats.spearmanr(
                    aligned["signal"].sample(frac=0.8, random_state=i),
                    aligned["fwd"].sample(frac=0.8, random_state=i),
                ).correlation
                for i in range(50)
            ])
            records.append(ICRecord(
                horizon_days=h,
                ic=round(float(corr), 4),
                ic_std=round(float(ic_std), 4),
                n_obs=len(aligned),
                p_value=round(float(pval), 4),
            ))
        return records


# ── Calibration Tracker ────────────────────────────────────────────────────────

class CalibrationTracker:
    """
    Checks that stated confidence ≈ actual hit rate.
    Confidence must earn trust through evidence (spec requirement).
    """

    def __init__(self):
        self.records: list[dict] = []

    def record(self, confidence: float, was_correct: bool):
        bucket = round(confidence * 10) / 10   # round to nearest 0.1
        self.records.append({"bucket": bucket, "correct": int(was_correct)})

    def report(self) -> pd.DataFrame:
        if not self.records:
            return pd.DataFrame()
        df = pd.DataFrame(self.records)
        summary = df.groupby("bucket")["correct"].agg(["mean", "count"]).reset_index()
        summary.columns = ["stated_confidence", "actual_hit_rate", "n_predictions"]
        summary["calibration_error"] = (
            summary["stated_confidence"] - summary["actual_hit_rate"]
        ).abs()
        return summary


# ── Signal Registry ────────────────────────────────────────────────────────────

class SignalRegistry:
    """Central registry — add signals, compute all, produce leaderboard."""

    def __init__(self):
        self._signals: list[BaseSignal] = []
        self.regime_detector = RegimeDetector()

    def register(self, signal: BaseSignal):
        self._signals.append(signal)

    def compute_all(
        self,
        price_dfs: dict[str, pd.DataFrame],
        as_of: dt.datetime,
        market_df: pd.DataFrame,
    ) -> list[SignalResult]:
        regime = self.regime_detector.detect(market_df)
        results = []
        for sig in self._signals:
            for symbol, df in price_dfs.items():
                if df.empty:
                    continue
                result = sig.evaluate(df, as_of, symbol, regime)
                if result:
                    results.append(result)
        return results

    def default_signals(self) -> "SignalRegistry":
        self.register(MomentumSignal())
        self.register(MeanReversionSignal())
        self.register(VolatilityRegimeSignal())
        self.register(VolumeBreakoutSignal())
        return self
