"""
Mentos Trading Connector — Alpaca Paper Trading
Defaults to paper trading. Will REFUSE to go live without two explicit confirmations.
Never hardcode API keys — use environment variables only.
"""

from __future__ import annotations
import os
import datetime as dt
from dataclasses import dataclass
from typing import Optional

# Alpaca SDK — installed via requirements.txt
try:
    from alpaca.trading.client import TradingClient
    from alpaca.trading.requests import MarketOrderRequest, LimitOrderRequest
    from alpaca.trading.enums import OrderSide, TimeInForce, OrderStatus
    from alpaca.data.historical import StockHistoricalDataClient
    from alpaca.data.requests import StockBarsRequest
    from alpaca.data.timeframe import TimeFrame
    ALPACA_AVAILABLE = True
except ImportError:
    ALPACA_AVAILABLE = False


# ── Safety Gate ────────────────────────────────────────────────────────────────

class LiveTradingRefused(Exception):
    """Raised when live trading is attempted without explicit double-confirmation."""
    pass


# ── Order Result ───────────────────────────────────────────────────────────────

@dataclass
class OrderResult:
    order_id: str
    symbol: str
    side: str           # 'buy' or 'sell'
    qty: float
    filled_price: Optional[float]
    status: str
    is_paper: bool
    timestamp: dt.datetime
    error: Optional[str] = None


# ── Alpaca Connector ───────────────────────────────────────────────────────────

class AlpacaConnector:
    """
    Paper trading connector for Alpaca.
    
    Setup:
    1. Go to alpaca.markets → sign up free → Paper Trading
    2. Get API Key ID and Secret Key from Paper Trading dashboard
    3. Set as environment variables:
       ALPACA_API_KEY_ID=your_key_here
       ALPACA_SECRET_KEY=your_secret_here
    4. Never paste these into any chat or code file.
    """

    PAPER_BASE_URL = "https://paper-api.alpaca.markets"
    LIVE_BASE_URL = "https://api.alpaca.markets"

    def __init__(self, paper: bool = True):
        """
        Always defaults to paper=True.
        Setting paper=False requires two separate explicit confirmations.
        """
        self.paper = paper
        self._confirmed_live_1 = False
        self._confirmed_live_2 = False
        self._client: Optional[object] = None

        if not ALPACA_AVAILABLE:
            raise ImportError(
                "alpaca-py not installed. Run: pip install alpaca-py"
            )

    def _load_credentials(self) -> tuple[str, str]:
        key = os.environ.get("ALPACA_API_KEY_ID", "")
        secret = os.environ.get("ALPACA_SECRET_KEY", "")
        if not key or not secret:
            raise EnvironmentError(
                "Alpaca credentials not found.\n"
                "Set these environment variables:\n"
                "  ALPACA_API_KEY_ID=your_key\n"
                "  ALPACA_SECRET_KEY=your_secret\n"
                "Never paste them into a chat or code file."
            )
        return key, secret

    def confirm_live_trading_step1(self):
        """First of two required confirmations to enable live trading."""
        self._confirmed_live_1 = True
        print("Step 1/2 confirmed. You must also call confirm_live_trading_step2().")

    def confirm_live_trading_step2(self):
        """Second confirmation. Both must be called to enable live trading."""
        if not self._confirmed_live_1:
            raise LiveTradingRefused("Step 1 not confirmed. Call confirm_live_trading_step1() first.")
        self._confirmed_live_2 = True
        print("WARNING: Live trading enabled. Real money will be used.")

    def connect(self) -> bool:
        """Connect to Alpaca. Validates that paper mode is used unless both confirmations given."""
        key, secret = self._load_credentials()

        if not self.paper:
            if not (self._confirmed_live_1 and self._confirmed_live_2):
                raise LiveTradingRefused(
                    "REFUSED: Live trading requires two explicit confirmations.\n"
                    "Call confirm_live_trading_step1() then confirm_live_trading_step2().\n"
                    "This system is designed for paper trading only."
                )

        base_url = self.PAPER_BASE_URL if self.paper else self.LIVE_BASE_URL
        self._client = TradingClient(
            api_key=key,
            secret_key=secret,
            paper=self.paper,
            url_override=base_url,
        )
        account = self._client.get_account()
        mode = "PAPER" if self.paper else "LIVE"
        print(f"Connected to Alpaca [{mode}] | Equity: ${float(account.equity):,.2f}")
        return True

    def get_account(self) -> dict:
        """Return current account info."""
        if not self._client:
            raise RuntimeError("Not connected. Call connect() first.")
        acc = self._client.get_account()
        return {
            "equity": float(acc.equity),
            "buying_power": float(acc.buying_power),
            "cash": float(acc.cash),
            "portfolio_value": float(acc.portfolio_value),
            "is_paper": self.paper,
        }

    def get_positions(self) -> list[dict]:
        """Return all current positions."""
        if not self._client:
            raise RuntimeError("Not connected.")
        positions = self._client.get_all_positions()
        return [{
            "symbol": p.symbol,
            "qty": float(p.qty),
            "avg_entry_price": float(p.avg_entry_price),
            "current_price": float(p.current_price) if p.current_price else None,
            "unrealized_pl": float(p.unrealized_pl) if p.unrealized_pl else 0.0,
            "unrealized_plpc": float(p.unrealized_plpc) if p.unrealized_plpc else 0.0,
        } for p in positions]

    def place_market_order(
        self,
        symbol: str,
        qty: float,
        side: str,              # 'buy' or 'sell'
        validate_inputs: bool = True,
    ) -> OrderResult:
        """Place a market order. Validates inputs before sending."""
        if not self._client:
            raise RuntimeError("Not connected.")

        # Input validation — never send garbage to the API
        if validate_inputs:
            if qty <= 0:
                raise ValueError(f"Invalid qty: {qty}. Must be > 0.")
            if symbol.upper() != symbol or len(symbol) > 5:
                raise ValueError(f"Invalid symbol format: {symbol}")
            if side not in ("buy", "sell"):
                raise ValueError(f"Invalid side: {side}. Must be 'buy' or 'sell'.")

        order_side = OrderSide.BUY if side == "buy" else OrderSide.SELL
        request = MarketOrderRequest(
            symbol=symbol,
            qty=qty,
            side=order_side,
            time_in_force=TimeInForce.DAY,
        )

        try:
            order = self._client.submit_order(request)
            return OrderResult(
                order_id=str(order.id),
                symbol=symbol,
                side=side,
                qty=qty,
                filled_price=float(order.filled_avg_price) if order.filled_avg_price else None,
                status=str(order.status),
                is_paper=self.paper,
                timestamp=dt.datetime.utcnow(),
            )
        except Exception as e:
            return OrderResult(
                order_id="error",
                symbol=symbol,
                side=side,
                qty=qty,
                filled_price=None,
                status="failed",
                is_paper=self.paper,
                timestamp=dt.datetime.utcnow(),
                error=str(e),
            )

    def cancel_all_orders(self):
        """Cancel all open orders — safety function."""
        if not self._client:
            raise RuntimeError("Not connected.")
        self._client.cancel_orders()
        print("All open orders cancelled.")

    def close_all_positions(self):
        """Close all positions — emergency function."""
        if not self._client:
            raise RuntimeError("Not connected.")
        self._client.close_all_positions(cancel_orders=True)
        print("All positions closed and orders cancelled.")
